﻿//namespace EndskApi.Api
//{
//    public static class BoosterApi
//    {
//        static BoosterApi()
//        {
//            //TODO CreateBoosterPatches
//        }

//        public static void AddBooster()
//        {

//        }
//    }
//}
