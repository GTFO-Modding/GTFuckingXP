﻿namespace EndskApi.Enums.Booster
{
    public enum CustomBoosterCategory
    {
        Muted,
        Bold,
        Aggressive,
        NotAccessible
    }
}
