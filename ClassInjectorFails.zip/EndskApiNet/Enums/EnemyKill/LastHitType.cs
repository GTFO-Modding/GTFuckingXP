﻿namespace EndskApi.Enums.EnemyKill
{
    public enum LastHitType
    {
        Melee,
        ShootyWeapon,
        Explosion
    }
}
