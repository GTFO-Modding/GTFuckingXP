﻿namespace EndskApi.Enums.Menus
{
    public enum InformationId
    {
        None,
        EnemyId,
    }
}
